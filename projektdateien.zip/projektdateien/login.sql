/*

	Meine initialisierende login Datei

*/
set sqlprompt '&_user@&_connect_identifier &_privilege> '
set echo off
set heading on
set pagesize 100
set linesize 120
set serveroutput on
define _editor='C:\Program Files (x86)\Notepad++\notepad++.exe'
set verify off

