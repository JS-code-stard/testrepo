/*

 Ein kleines Hallo Welt Programm

*/
BEGIN
	dbms_output.put_line('Hallo Welt');
END;
/


